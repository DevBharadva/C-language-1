#include <stdio.h>
int main()
{
		printf("\n program 6,oddwhile \n");
		
		int i=1;
		
		while(i<50)
		{
			printf("%d\t",i++);
			i++;
			
		}
		return 0;
}