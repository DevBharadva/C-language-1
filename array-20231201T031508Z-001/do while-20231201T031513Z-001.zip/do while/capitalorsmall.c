#include <stdio.h>
int main()
{
		int i;
		printf("\n program 9,capital or small \n");
		i=65;
		while(i<=90)
		{
			printf("%c %c \t",i,i+32);
			i++;
		}
		return 0;
}