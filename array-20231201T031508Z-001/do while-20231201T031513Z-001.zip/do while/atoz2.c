#include <stdio.h>
int main()
{
		int i;
		printf("\n program 10,atoz \n");
		
		i=65;
		
		while(i<=90)
		{
			printf("%c \t",i);
			i++;
			
		}
		return 0;
}