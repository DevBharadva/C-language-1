#include <stdio.h>
int main()
{
		int i;
printf("\n program 8,atoz \n");
		
		i=65;
		
		while(i<=90)
		{
			printf("%c %d\t",i,i);
			i++;
			
		}
		return 0;
}
		