#include <stdio.h>
int main()
{
		int a;
printf("\nprogram 2,1to5\n");
	
	a=10;

		while(a>0)
		{
			printf("%d\t",a);
			a--;	
		}
		return 0;
}
