#include <stdio.h>
int main()
{
		int i;
printf("\n program 7,evenwhile \n");
		
		i=0;
		
		while(i<50)
		{
			printf("%d \t",i++);
			i++;
			
		}
		return 0;
}