#include <stdio.h>

int main()
{
	int a=0;
	
	printf("\nprogram 1,1to5\n");
	
	while(a<=5)
	{
		printf("%d dev\n",a);
		a++;
	}
	return 0;
}