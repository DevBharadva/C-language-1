#include <stdio.h>
int main()
{
    int a= 5;
    int b= 4;

    printf("Bitwise and of a & b is: %d\n",a&b);
    printf("bitwise and of a & b is: %d",a|b);
    return 0;

}
