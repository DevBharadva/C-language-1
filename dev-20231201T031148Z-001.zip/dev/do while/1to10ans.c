#include <stdio.h>
int main()
{
		int i;
	printf("\n program 13,total 1to10ans \n");
		
		i=1;
		
		int ans=0;
		while(i<=10)
		{
			
			ans+=i;
			printf("%d\t",i);
			i++;
		}
		printf("%d\t",ans);
		
		
	
return 0;
}