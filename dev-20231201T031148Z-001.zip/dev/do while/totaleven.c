#include <stdio.h>
int main()
{
		int i;
printf("\n program 12,total even \n");
		
		i=2;
		
		sum=0;
		while(i<=10)
		{
			
			sum+=i;
			printf("%d\t",i++);
			i++;
		}
		printf("%d\t",sum);
		return 0;
}