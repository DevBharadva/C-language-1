#include <stdio.h>
int main()
}
		printf("\nprogram 5, -nton \n");
		
		int i,n;
		
		printf("enter the value\t");
		scanf("%d",&n);
		
		while(i<=n)
		{
			printf("%d\t",i);
			i++;
			
		}
		return 0;
}