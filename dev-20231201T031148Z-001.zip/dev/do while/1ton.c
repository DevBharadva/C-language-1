#include <stdio.h>
int main()
{
printf("\n program 4,1ton \n");
		
		int i,n;
		i=0;
		
		printf("enter the value\t");
		scanf("%d",&n);
		
		while(i<=n)
		{
			printf("%d\t",i);
			i++;
			
		}
		return 0;
		}