#include <stdio.h>

int main()
{
	int a=0;
	
	while(a<=5)
	{
		printf("%d dev\n",a);
		a++;
	}
	
return 0;
}