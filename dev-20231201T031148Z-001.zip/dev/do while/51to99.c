#include <stdio.h>
int main()
{
		int a;
printf("\n program 3,51to99 \n");
		
		a=51;
		
		while(a<100)
		{
			
			printf("%d\t",a);
			a++;
		}
		return 0;
		}
		
		