#include <stdio.h>
#iunclude <string.h>
void revers()
{
	char a[10];
	printf("enter the value: \n");
	scanf("%d",a);
	
	int i,j,len;
	
	len = strlen(a);
	for(i=len;i>=0;i--)
	{
		printf("%c",a(i));
		
	}
}
		int main()
		{
			revers();

}