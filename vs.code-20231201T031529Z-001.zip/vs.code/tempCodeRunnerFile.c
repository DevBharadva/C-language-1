#include <stdio.h>
int mai9n()
{
    int a= 5;
    int b= 4;

    printf("Bitwise and of a & b is: %d",a&b);
    return 0;

}