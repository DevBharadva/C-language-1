#include<stdio.h>
int main()
{
	char arra[42];
	int s;
	for(s=0;s<10;s++)
	{
	scanf("%c",&arra[s]);
	}
	for(s=0;s<10;s++)
	{
	printf("%c",arra[s]);
	}
	return 0;
	}