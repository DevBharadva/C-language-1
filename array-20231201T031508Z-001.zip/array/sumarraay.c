#include <stdio.h>
int main()
{
	printf("even value for array loop :\n");
	
	int i[50],j,sum=0;
	
	for(j=1;j<=20;j++)
	{
		scanf("%d",&i[j]);
	}
	printf("\n");
	for(j=;j<=5;j++)
	{
		if(i[j]%2==0)
		{
			printf("per[%d]=%d\t",i,per[i]);
			sum+=i[j];
		}
		//printf("%d\n",sum);
		
return 0;
	}
	
	/* #include <stdio.h>
int main()
{
	int per[100],i,sum=0;

		for(i=1;i<=10;i++)
		{
			printf("enter the your value[%d]:\t",i);
			scanf("%d",&per[i]);
		}
		printf("\n");
		for(i=10;i>=1;i--)
		{
			
			printf("per[%d]=%d\t",i,per[i]);
			sum=sum+per[i];
		}
		//printf("%d",sum);
	
	return 0;
}
	
	jjhgjhjhgh